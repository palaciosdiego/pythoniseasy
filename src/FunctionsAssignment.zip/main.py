# My favorite song

"""
    These file is my first homework assingment, it covers the 
    first level named "Variables" of the course "Python is easy"
"""

"""
    These are the principal,
    attributes of my favorite song
"""

Name = "Time"
Artist = "Pink Floyd"
Album = "The Dark Side of the Moon"
YearReleased = 1973
Genres = "Rock, Progressive Rock progresivo, Psychedelic Rock"
Duration = 6.54
Authors = "David Jon Gilmour / Nicholas Berkeley Mason / George Roger Waters / Richard William Wright"
DurationInSeconds = (6*60) + 54


# Printing the variables

print(Artist)
print(Album)
print(YearReleased)
print(Genres)
print(Duration)
print(Authors)
print(DurationInSeconds)
